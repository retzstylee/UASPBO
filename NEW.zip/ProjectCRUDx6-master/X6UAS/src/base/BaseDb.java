package base;

/**
 *
 * @author brilyan
 */
public interface BaseDb {
    public void disconnect();
}
